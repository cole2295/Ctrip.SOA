﻿安装提示：
请将此目录下的所有文件拷贝到C:\DevTools\ConfigGen，否则程序不能正常工作!

ConfigGen.exe启动时将自动检查升级，如果失败可手动更新
手动更新时，只需要将core.zip和upgrade.xml拷贝至以上目录重启应用即可